package entity;

public abstract class Donation {
    private int id;
    private String donorName;
    private double amount;

    public Donation(int id, String donorName, double amount) {
        this.id = id;
        this.donorName = donorName;
        this.amount = amount;
    }

    public int getId() { return id; }
    public String getDonorName() { return donorName; }
    public double getAmount() { return amount; }

    public abstract void recordDonation();
}

