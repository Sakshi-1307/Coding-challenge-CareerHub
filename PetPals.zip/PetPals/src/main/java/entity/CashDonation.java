package entity;


import java.time.LocalDate;

public class CashDonation extends Donation {
    private LocalDate donationDate;

    public CashDonation(int id, String donorName, double amount, LocalDate donationDate) {
        super(id, donorName, amount);
        this.donationDate = donationDate;
    }

    @Override
    public void recordDonation() {
        System.out.println("Cash donation recorded: " + getAmount() + " by " + getDonorName() + " on " + donationDate);
    }

    public LocalDate getDonationDate() { return donationDate; }
}
