package entity;

public class Cat extends Pet {
    private String catColor;

    public Cat(int id, String name, int age, String breed, boolean adopted, String catColor) {
        super(id, name, age, breed, adopted);
        this.catColor = catColor;
    }

    public String getCatColor() { return catColor; }
    public void setCatColor(String catColor) { this.catColor = catColor; }

    @Override
    public String toString() {
        return "Cat{" + super.toString() +
                ", catColor='" + catColor + '\'' +
                '}';
    }
}