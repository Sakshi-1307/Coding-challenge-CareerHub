package org.example.dao;

import org.example.entity.Admin;
import java.util.List;


public interface AdminDao {
    Admin getAdminById(int adminId);
    Admin getAdminByUsername(String username);
    boolean registerAdmin(Admin admin);
    boolean updateAdmin(Admin admin);
    boolean deleteAdmin(int adminId);
}
