package org.example.dao;

import org.example.entity.Customer;
import org.example.exception.DatabaseConnectionException;
import org.example.util.DBConnUtil;
import org.example.util.DBPropertyUtil;

import java.sql.*;
import java.time.LocalDate;
import java.util.Optional;

public class CustomerDaoImpl implements CustomerDao {
    private final String connectionString;

    public CustomerDaoImpl() {
        this.connectionString = DBPropertyUtil.getConnectionString("db.properties");
    }

    @Override
    public Optional<Customer> getCustomerById(int customerId) {
        String query = "SELECT * FROM Customer WHERE CustomerID = ?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Customer customer = extractCustomerFromResultSet(rs);
                return Optional.of(customer);
            }
        } catch (SQLException e) {
            throw new DatabaseConnectionException("Error getting customer by ID", e);
        }
        return Optional.empty();
    }

    @Override
    public Optional<Customer> getCustomerByUsername(String username) {
        String query = "SELECT * FROM Customer WHERE Username = ?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Customer customer = extractCustomerFromResultSet(rs);
                return Optional.of(customer);
            }
        } catch (SQLException e) {
            throw new DatabaseConnectionException("Error getting customer by username", e);
        }
        return Optional.empty();
    }

    @Override
    public boolean registerCustomer(Customer customer) {
        String query = "INSERT INTO Customer (FirstName, LastName, Email, PhoneNumber, Address, Username, Password, RegistrationDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, customer.getFirstName());
            stmt.setString(2, customer.getLastName());
            stmt.setString(3, customer.getEmail());
            stmt.setString(4, customer.getPhoneNumber());
            stmt.setString(5, customer.getAddress());
            stmt.setString(6, customer.getUsername());
            stmt.setString(7, customer.getPassword());
            stmt.setDate(8, Date.valueOf(customer.getRegistrationDate()));
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseConnectionException("Error registering customer", e);
        }
    }

    @Override
    public boolean updateCustomer(Customer customer) {
        String query = "UPDATE Customer SET FirstName=?, LastName=?, Email=?, PhoneNumber=?, Address=?, Username=?, Password=?, RegistrationDate=? WHERE CustomerID=?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, customer.getFirstName());
            stmt.setString(2, customer.getLastName());
            stmt.setString(3, customer.getEmail());
            stmt.setString(4, customer.getPhoneNumber());
            stmt.setString(5, customer.getAddress());
            stmt.setString(6, customer.getUsername());
            stmt.setString(7, customer.getPassword());
            stmt.setDate(8, Date.valueOf(customer.getRegistrationDate()));
            stmt.setInt(9, customer.getCustomerID());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseConnectionException("Error updating customer", e);
        }
    }

    @Override
    public boolean deleteCustomer(int customerId) {
        String query = "DELETE FROM Customer WHERE CustomerID = ?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, customerId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseConnectionException("Error deleting customer", e);
        }
    }

    private Customer extractCustomerFromResultSet(ResultSet rs) throws SQLException {
        Customer customer = new Customer();
        customer.setCustomerID(rs.getInt("CustomerID"));
        customer.setFirstName(rs.getString("FirstName"));
        customer.setLastName(rs.getString("LastName"));
        customer.setEmail(rs.getString("Email"));
        customer.setPhoneNumber(rs.getString("PhoneNumber"));
        customer.setAddress(rs.getString("Address"));
        customer.setUsername(rs.getString("Username"));
        customer.setPassword(rs.getString("Password"));

        Date regDate = rs.getDate("RegistrationDate");
        customer.setRegistrationDate(regDate != null ? regDate.toLocalDate() : LocalDate.now()); // fallback if null

        return customer;
    }
}
