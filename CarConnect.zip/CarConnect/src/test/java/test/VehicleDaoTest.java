package test;

import org.example.dao.VehicleDaoImpl;
import org.example.entity.Vehicle;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

public class VehicleDaoTest {

    private VehicleDaoImpl vehicleDao;

    @BeforeEach
    void setUp() {
        vehicleDao = new VehicleDaoImpl();
    }

    @Test
    void testAddVehicle() {
        Vehicle vehicle = new Vehicle();
        vehicle.setMake("Toyota");
        vehicle.setModel("Corolla");
        vehicle.setYear(2020);
        vehicle.setColor("Blue");
        vehicle.setRegistrationNumber("XYZ987");
        vehicle.setAvailability(true);
        vehicle.setDailyRate(55.5);
        boolean added = vehicleDao.addVehicle(vehicle);
        Assertions.assertTrue(added, "Vehicle should be added successfully.");
    }

    @Test
    void testUpdateVehicle() {
        Vehicle vehicle = vehicleDao.getVehicleById(1);
        Assertions.assertNotNull(vehicle);
        vehicle.setColor("Red");
        boolean updated = vehicleDao.updateVehicle(vehicle);
        Assertions.assertTrue(updated, "Vehicle update should succeed.");
    }

    @Test
    void testGetAvailableVehicles() {
        List<Vehicle> available = vehicleDao.getAvailableVehicles();
        Assertions.assertNotNull(available);
        Assertions.assertFalse(available.isEmpty(), "There should be available vehicles.");
    }

    @Test
    void testGetAllVehicles() {
        List<Vehicle> all = vehicleDao.getAllVehicles();
        Assertions.assertNotNull(all);
        Assertions.assertFalse(all.isEmpty(), "There should be some vehicles.");
    }
}