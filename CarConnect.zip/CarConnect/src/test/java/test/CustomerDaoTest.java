package test;

import org.example.dao.CustomerDao;
import org.example.dao.CustomerDaoImpl;
import org.example.entity.Customer;
import org.junit.jupiter.api.*;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class CustomerDaoTest {

    private static CustomerDao customerDao;
    private static int testCustomerId;

    @BeforeAll
    public static void setup() {
        customerDao = new CustomerDaoImpl();
    }

    @Test
    @Order(1)
    public void testRegisterCustomer() {
        Customer customer = new Customer();
        customer.setFirstName("Test");
        customer.setLastName("User");
        customer.setEmail("testuser@example.com");
        customer.setPhoneNumber("1234567890");
        customer.setAddress("Test City");
        customer.setUsername("testuser123");
        customer.setPassword("password123");
        customer.setRegistrationDate(LocalDate.now());

        boolean isRegistered = customerDao.registerCustomer(customer);
        assertTrue(isRegistered, "Customer should be registered successfully");

        Optional<Customer> optional = customerDao.getCustomerByUsername("testuser123");
        assertTrue(optional.isPresent(), "Registered customer should be fetched");

        testCustomerId = optional.get().getCustomerID();
    }

    @Test
    @Order(2)
    public void testUpdateCustomer() {
        Optional<Customer> optional = customerDao.getCustomerByUsername("testuser123");
        assertTrue(optional.isPresent());

        Customer customer = optional.get();
        customer.setAddress("Updated Address");
        boolean updated = customerDao.updateCustomer(customer);
        assertTrue(updated, "Customer should be updated");
    }

    @Test
    @Order(3)
    public void testDeleteCustomer() {
        boolean deleted = customerDao.deleteCustomer(testCustomerId);
        assertTrue(deleted, "Customer should be deleted");
    }

    // Optional: Manual execution using main()
    public static void main(String[] args) {
        setup();
        CustomerDaoTest test = new CustomerDaoTest();
        test.testRegisterCustomer();
        test.testUpdateCustomer();
        test.testDeleteCustomer();
        System.out.println(" tests executed.");
    }
}