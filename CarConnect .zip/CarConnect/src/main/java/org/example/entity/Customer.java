package org.example.entity;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class Customer {
    private int customerID;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private String address;
    private String username;
    private String password;
    private Date registrationDate; // Keep Date internally

    // Default constructor
    public Customer() {
    }

    // Parameterized constructor
    public Customer(int customerID, String firstName, String lastName, String email,
                    String phoneNumber, String address, String username,
                    String password, LocalDate registrationDate) {
        this.customerID = customerID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.username = username;
        this.password = password;
        this.registrationDate = Date.from(registrationDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
    }

    // Getters and Setters
    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // Store as Date, return as LocalDate
    public LocalDate getRegistrationDate() {
        return registrationDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

    // Accept LocalDate and convert to Date
    public void setRegistrationDate(LocalDate registrationDate) {
        this.registrationDate = Date.from(registrationDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
    }

    public Date getRegistrationDateAsDate() {
        return registrationDate;
    }

    public void setRegistrationDateAsDate(Date registrationDate) {
        this.registrationDate = registrationDate;
    }
}
