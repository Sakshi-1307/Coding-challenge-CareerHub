package test;

import org.example.dao.CustomerDao;
import org.example.dao.CustomerDaoImpl;
import org.example.entity.Customer;
import org.junit.jupiter.api.*;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class CustomerDaoTest {

    private static CustomerDao customerDao;
    private static int testCustomerId;

    @BeforeAll
    public static void setup() {
        customerDao = new CustomerDaoImpl();
    }



    @Test
    @Order(1)
    public void testUpdateCustomer() {
        Optional<Customer> optional = customerDao.getCustomerByUsername("testuser123");
        assertTrue(optional.isPresent());

        Customer customer = optional.get();
        customer.setAddress("Updated Address");
        boolean updated = customerDao.updateCustomer(customer);
        assertTrue(updated, "Customer should be updated");
    }


    // Optional: Manual execution using main()

}