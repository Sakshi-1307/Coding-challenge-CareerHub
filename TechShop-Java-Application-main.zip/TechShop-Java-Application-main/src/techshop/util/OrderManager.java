package techshop.util;

import techshop.model.Orders;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class OrderManager {
    private List<Orders> ordersList;

    public OrderManager() {
        this.ordersList = new ArrayList<>();
    }

    public void addOrder(Orders order) {
        ordersList.add(order);
    }

    public void removeOrder(int orderId) {
        ordersList.removeIf(order -> order.getOrderID() == orderId);
    }

    public void updateOrderStatus(int orderId, String newStatus) {
        for (Orders order : ordersList) {
            if (order.getOrderID() == orderId) {
                order.updateOrderStatus(newStatus);
                break;
            }
        }
    }

    public void displayAllOrders() {
        for (Orders order : ordersList) {
            System.out.println("Order ID: " + order.getOrderID());
            System.out.println("Order Date: " + order.getOrderDate());
            System.out.println("Customer: " + order.getCustomer().getFirstName() + " " + order.getCustomer().getLastName());
            System.out.println("Total Amount: " + order.getTotalAmount());
            System.out.println("---------------------------");
        }
    }

    public void sortOrdersByDateAscending() {
        Collections.sort(ordersList, Comparator.comparing(Orders::getOrderDate));
    }

    public void sortOrdersByDateDescending() {
        Collections.sort(ordersList, Comparator.comparing(Orders::getOrderDate).reversed());
    }

    public List<Orders> getOrdersList() {
        return ordersList;
    }
}
