package techshop.util;

import techshop.model.Product;
import java.util.*;

public class ProductManager {
    private List<Product> productList = new ArrayList<>();

    public void addProduct(Product product) throws Exception {
        for (Product p : productList) {
            if (p.getProductID() == product.getProductID()) {
                throw new Exception("Duplicate product ID not allowed.");
            }
        }
        productList.add(product);
    }

    public void removeProduct(int productId) {
        productList.removeIf(p -> p.getProductID() == productId);
    }

    public Product getProductById(int productId) {
        return productList.stream()
                .filter(p -> p.getProductID() == productId)
                .findFirst()
                .orElse(null);
    }

    public List<Product> searchByName(String name) {
        List<Product> results = new ArrayList<>();
        for (Product p : productList) {
            if (p.getProductName().toLowerCase().contains(name.toLowerCase())) {
                results.add(p);
            }
        }
        return results;
    }

    public List<Product> getAllProducts() {
        return productList;
    }
}
