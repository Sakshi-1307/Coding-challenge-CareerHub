package techshop.model;

import techshop.exception.IncompleteOrderException;
import java.time.LocalDate;

public class OrderDetails {
    private int orderDetailID;
    private Orders order;        // Composition: referencing the order
    private Product product;     // Composition: referencing the product
    private int quantity;
    private double discount;     // Optional: track discount for AddDiscount()

    // Constructor
    public OrderDetails(int orderDetailID, Orders order, Product product, int quantity) {
        this.orderDetailID = orderDetailID;
        this.order = order;
        this.product = product;
        this.quantity = quantity;
        this.discount = 0.0; // Default no discount
    }

    // Method to calculate subtotal with discount
    public double calculateSubtotal() {
        double subtotal = product.getPrice() * quantity;
        return subtotal - discount;
    }

    // Method to get order detail info
    public void getOrderDetailInfo() {
        System.out.println("Order Detail ID: " + orderDetailID);
        System.out.println("Product: " + product.getProductName());
        System.out.println("Quantity: " + quantity);
        System.out.println("Subtotal: " + calculateSubtotal());
    }

    public void validate() throws IncompleteOrderException {
        if (product == null) {
            throw new IncompleteOrderException("Product cannot be null in Order Detail.");
        }
    }

    // Method to update quantity
    public void updateQuantity(int newQuantity) {
        this.quantity = newQuantity;
    }

    // Method to apply discount
    public void addDiscount(double discountAmount) {
        this.discount = discountAmount;
    }

    // Getters and Setters

    public int getOrderDetailID() {
        return orderDetailID;
    }

    public void setOrderDetailID(int orderDetailID) {
        this.orderDetailID = orderDetailID;
    }

    public Orders getOrder() {
        return order;
    }

    public void setOrder(Orders order) {
        this.order = order;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }
}
