package techshop.model;

import techshop.exception.InsufficientStockException;

import java.time.LocalDate;
import java.util.List;

public class Inventory {
    private int inventoryID;
    private Product product;
    private int quantityInStock;
    private LocalDate lastStockUpdate;

    // Constructor
    public Inventory(int inventoryID, Product product, int quantityInStock) {
        this.inventoryID = inventoryID;
        this.product = product;
        this.quantityInStock = quantityInStock;
        this.lastStockUpdate = LocalDate.now();
    }

    // Getters and Setters
    public int getInventoryID() {
        return inventoryID;
    }

    public void setInventoryID(int inventoryID) {
        this.inventoryID = inventoryID;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public int getQuantityInStock() {
        return quantityInStock;
    }

    public void setQuantityInStock(int quantityInStock) {
        this.quantityInStock = quantityInStock;
    }

    public LocalDate getLastStockUpdate() {
        return lastStockUpdate;
    }

    public void setLastStockUpdate(LocalDate lastStockUpdate) {
        this.lastStockUpdate = lastStockUpdate;
    }

    // Functional Methods
    public void addToInventory(int quantity) {
        this.quantityInStock += quantity;
        this.lastStockUpdate = LocalDate.now();
    }

    public void removeFromInventory(int quantity) throws InsufficientStockException {
        if (quantity > quantityInStock) {
            throw new InsufficientStockException("Not enough stock to remove " + quantity + " items.");
        }
        this.quantityInStock -= quantity;
        this.lastStockUpdate = LocalDate.now();
    }

    public void updateStockQuantity(int newQuantity) {
        this.quantityInStock = newQuantity;
        this.lastStockUpdate = LocalDate.now();
    }

    public boolean isProductAvailable(int quantityToCheck) {
        return quantityInStock >= quantityToCheck;
    }

    public double getInventoryValue() {
        return product.getPrice() * quantityInStock;
    }

    // Static Helper Methods
    public static void listLowStockProducts(List<Inventory> inventoryList, int threshold) {
        System.out.println("Products with low stock (less than " + threshold + "):");
        for (Inventory inv : inventoryList) {
            if (inv.quantityInStock < threshold) {
                System.out.println(inv.product.getProductName() + " - Quantity: " + inv.quantityInStock);
            }
        }
    }

    public static void listOutOfStockProducts(List<Inventory> inventoryList) {
        System.out.println("Out of stock products:");
        for (Inventory inv : inventoryList) {
            if (inv.quantityInStock == 0) {
                System.out.println(inv.product.getProductName());
            }
        }
    }

    public static void listAllProducts(List<Inventory> inventoryList) {
        System.out.println("All products in inventory:");
        for (Inventory inv : inventoryList) {
            System.out.println("Product: " + inv.product.getProductName() +
                    " | Quantity: " + inv.quantityInStock +
                    " | Last Updated: " + inv.lastStockUpdate);
        }
    }
}
