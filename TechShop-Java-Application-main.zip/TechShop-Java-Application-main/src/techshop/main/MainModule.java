package techshop.main;

import techshop.dao.*;
import techshop.model.*;
import techshop.util.*;
import techshop.exception.*;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.*;

public class MainModule {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // DAO and Manager Initializations1
        CustomerDAO customerDAO = new CustomerDAO();
        ProductDAO productDAO = new ProductDAO();
        OrderDAO orderDAO = new OrderDAO();
        OrderDetailsDAO orderDetailsDAO = new OrderDetailsDAO();
        InventoryDAO inventoryDAO = new InventoryDAO();

        ProductManager productManager = new ProductManager();
        InventoryManager inventoryManager = new InventoryManager();

        boolean running = true;

        while (running) {
            System.out.println("\n==== Welcome to TechShop ====");
            System.out.println("1. Register Customer");
            System.out.println("2. Add Product");
            System.out.println("3. Add Inventory");
            System.out.println("4. View All Products");
            System.out.println("5. View Low Stock Products");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            try {
                switch (choice) {

                    case 1: // Register Customer
                        System.out.print("Enter first name: ");
                        String fname = scanner.nextLine();
                        System.out.print("Enter last name: ");
                        String lname = scanner.nextLine();
                        System.out.print("Enter email: ");
                        String email = scanner.nextLine();
                        System.out.print("Enter phone: ");
                        String phone = scanner.nextLine();
                        System.out.print("Enter address: ");
                        String address = scanner.nextLine();

                        Customer customer = new Customer(0, fname, lname, email, phone, address);
                        customerDAO.addCustomer(customer);
                        System.out.println("✅ Customer registered successfully!");
                        break;

                    case 2: // Add Product
                        System.out.print("Enter product name: ");
                        String pname = scanner.nextLine();
                        System.out.print("Enter description: ");
                        String desc = scanner.nextLine();
                        System.out.print("Enter price: ");
                        double price = scanner.nextDouble();

                        Product product = new Product(0, pname, desc, price);
                        productDAO.addProduct(product);
                        productManager.addProduct(product);
                        System.out.println("✅ Product added.");
                        break;

                    case 3: // Add Inventory
                        System.out.print("Enter product ID to add stock for: ");
                        int pid = scanner.nextInt();
                        Product invProduct = productDAO.getProductById(pid);

                        if (invProduct == null) {
                            System.out.println("❌ Product not found.");
                            break;
                        }

                        System.out.print("Enter stock quantity: ");
                        int qty = scanner.nextInt();

                        Inventory inventory = new Inventory(0, invProduct, qty);
                        inventoryDAO.addInventory(inventory);
                        inventoryManager.addOrUpdateInventory(inventory);

                        System.out.println("✅ Inventory updated.");
                        break;


                    case 4: // View All Products
                        List<Product> allProducts = productDAO.getAllProducts();
                        for (Product p : allProducts) {
                            p.getProductDetails();
                            System.out.println("------------------");
                        }
                        break;

                        /*
                    case 5: // Low Stock Products
                        System.out.print("Enter threshold quantity: ");
                        int threshold = scanner.nextInt();
                        List<Inventory> lowStockList = inventoryDAO.getLowStockProducts(threshold);
                        for (Inventory i : lowStockList) {
                            System.out.println(i.getProduct().getProductName() + " | Qty: " + i.getQuantityInStock());
                        }
                        break;

                         */

                    case 5: // Low Stock Products
                        System.out.print("Debug... ");
                        System.out.print("Enter threshold quantity: ");
                        int threshold = scanner.nextInt();
                        System.out.print("Entered Threshold: "+ threshold);
                        List<Inventory> lowStockList = inventoryDAO.getLowStockProducts(threshold);
                        System.out.print("Debug retrived "+ lowStockList.size()+"records");
                        for (Inventory i : lowStockList) {
                            System.out.println(i.getProduct().getProductName() + " | Qty: " + i.getQuantityInStock());
                        }
                        break;






                    case 6:
                        running = false;
                        System.out.println("👋 Exiting TechShop. Goodbye!");
                        break;

                    default:
                        System.out.println("⚠️ Invalid choice.");
                }
            } catch (InvalidDataException | InsufficientStockException | SQLException ex) {
                System.out.println("❌ Error: " + ex.getMessage());
            } catch (Exception e) {
                System.out.println("❌ Unexpected error: " + e.getMessage());
                e.printStackTrace();
            }
        }

        scanner.close();
    }
}
